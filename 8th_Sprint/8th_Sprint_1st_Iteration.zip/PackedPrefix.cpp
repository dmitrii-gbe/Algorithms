// https://contest.yandex.ru/contest/26133/run-report/119136882/
/*
-- ПРИНЦИП РАБОТЫ --
Решение принимает массив ЗС, после чего с помошью функций UnPack и MultiplyStringByCount рекурсивно ее
распаковывает. Затем функция GetCommonPrefix ищет общий префикс распакованных строк.


-- ДОКАЗАТЕЛЬСТВО КОРРЕКТНОСТИ --
На вход подается строка, запакованная рекурсивно, то есть при распаковке ЗС может снова получиться
запакованная строка. Поэтому алгоритм рекурсивно доходит до максимальной уровня упаковки, после чего
последательно для каждого уровня распаковывает содержимое, получая, таким образом исходные неупаковованные
строки, для которых затем вычисляется общий префикс максимальной длины.

-- ВРЕМЕННАЯ СЛОЖНОСТЬ --
Распаковка строки имеет сложность O(N^2), где N - длина запакованной строки, так как на каждом
уровне нужно найти закрывающий символ ']'. Поиск общего префикса имеет сложность O(n * M), где n - число
строк, а M - длина самой короткой распакованной строки. В худшем случае сложность этого шага составит O(U),
где U - совокупная длина распакованных строк. Таким образом, общая сложность - не более O(P^2) + O(U), где P и
U - совокупная длина запакованных и распакованных строк, соответственно.

-- ПРОСТРАНСТВЕННАЯ СЛОЖНОСТЬ --

Алгоритм требует не более O(P + U) памяти, где P и U - общая длина запакованных и распакованных строк,
соответственно.
*/

#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

std::vector<std::string> GetStrings(int n) {
    std::vector<std::string> result(n);
    int index = 0;
    while (index != n) {
        std::cin >> result[index++];
    }
    return result;
}

std::string MultiplyStringByCount(int n, const std::string &str) {
    std::string result;
    result.reserve(str.size() * n);
    while (n != 0) {
        result += str;
        --n;
    }
    return result;
}

size_t FindClosingBracket(const std::string &str, size_t start_index) {
    int brackets_count = 1;
    ++start_index;
    while (brackets_count != 0) {
        if (str[start_index] == '[') {
            ++brackets_count;
        } else if (str[start_index] == ']') {
            --brackets_count;
        }
        ++start_index;
    }
    return start_index;
}

std::string UnPack(const std::string &str) {
    std::string result;
    for (size_t i = 0; i < str.size();) {
        if (str[i] >= 'a' && str[i] <= 'z') {
            result += str[i++];
        } else if (str[i] >= '0' && str[i] <= '9') {
            size_t shift = FindClosingBracket(str, i + 1) - i;
            result += MultiplyStringByCount(str[i] - '0', UnPack(str.substr(i + 2, shift - 3)));
            i += shift;
        }
    }
    return result;
}

std::string GetCommonPrefix(const std::vector<std::string> &v) {
    size_t min_length = v[0].size();
    for (const auto &string : v) {
        min_length = std::min(min_length, string.size());
    }
    size_t i = 0;
    for (; i < min_length; ++i) {
        char c = v[0][i];
        if (std::any_of(v.begin(), v.end(), [c, i](const auto &string) { return string[i] != c; })) {
            break;
        }
    }
    return v[0].substr(0, i);
}

int main() {
    int count = 0;
    std::cin >> count;
    std::vector<std::string> packed_strings = GetStrings(count);
    std::vector<std::string> unpacked_strings;
    for (const auto &string : packed_strings) {
        unpacked_strings.push_back(UnPack(string));
    }
    std::cout << GetCommonPrefix(unpacked_strings);
    return 0;
}

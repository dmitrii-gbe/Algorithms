// https://contest.yandex.ru/contest/26133/run-report/119074449/
/*
-- ПРИНЦИП РАБОТЫ --
Решение принимает строку и массив слов, на которые ее предполагается разбить. Затем функция MapWordsToText
выполняет поиск вхождений каждого слова в строку с помощью алгоритма Кнута-Мориса-Пратта и сохраняет
интервалы, образованные индексами вхождений слов в строку. Затем функция IsPossibleToSplit определяет, можно
ли строку полностью покрыть последовательностью неперекрывающихся интервалов.


-- ДОКАЗАТЕЛЬСТВО КОРРЕКТНОСТИ --
Возможность накрыть строку последоватьностью неперекрывающихся интервалов определяется тем, есть ли интервал,
конец которого соответствует последнему символу строки, а начало располагается сразу за концом другого
интервала. Значит, чтобы ответить на исходный вопрос, нужно проверить все интеравалы, индекс конца которых
меньше текущего. Таким образом, массив интервалов необходимо отсортировать по возрастанию индекса конца и
последовательно перебрать, запоминая для каждого индекса конца, есть ли слева последовательность интервалов,
которую можно продолжить текущим. При условии, что найдется такая последовательность, оканчивающаяся индексом
последнего символа в строке, алгоритм дает положительный ответ.

-- ВРЕМЕННАЯ СЛОЖНОСТЬ --
Временная сложность поиска слов в строке - O(N + n*M), где M - длина строки, N - сумма длин слов, а n - число
слов. Временная сложность выстраивания последовательности интервалов линейно зависит от числа интервалов.
В худшем случае для каждого слова число вхождений будет сопоставимо с длиной строки, поэтому в худшем случае
сложность этого этапа O(n*M), где n - число слов, а M - длина строки. Это возможно, если и строка и слова
имеют регулярную структуру. В лучшем случае сложность составит O(n), где n - число слов, если каждое слово
найдется в строке фиксированное (независящее от длины строки) число раз.

-- ПРОСТРАНСТВЕННАЯ СЛОЖНОСТЬ --

Ни один из этапов алгоритма не требует более O(N + M) памяти, где N - суммарная длина слов, а M - длина
строки. Исключение - массив интервалов, который в худшем случае может может потребовать O(n*M), где n - число
слов, а M - длина строки.
*/

#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

struct Interval {
    int start = 0;
    int end = 0;
};

std::vector<std::string> GetWords(int n) {
    std::vector<std::string> result(n);
    int index = 0;
    while (index != n) {
        std::cin >> result[index++];
    }
    return result;
}

std::vector<int> GetPrefix(const std::string &s) {
    std::vector<int> prefix(s.size(), 0);
    for (size_t i = 1; i < s.size(); ++i) {
        int current = prefix[i - 1];

        while (s[i] != s[current] && current > 0) {
            current = prefix[current - 1];
        }

        if (s[i] == s[current]) {
            prefix[i] = current + 1;
        }
    }
    return prefix;
}

void FindWordOccurences(const std::string &text, const std::string &pattern, std::vector<Interval> &storage) {
    std::string s = pattern + char(0) + text;
    auto prefix = GetPrefix(s);
    for (size_t i = pattern.size() + 1; i < prefix.size(); ++i) {
        if (prefix[i] == (int)pattern.size()) {
            int start = i - 2 * pattern.size();
            int end = start + pattern.size() - 1;
            storage.push_back({start, end});
        }
    }
}

std::vector<Interval> MapWordsToText(const std::string &text, const std::vector<std::string> &dictionary) {
    std::vector<Interval> result;
    for (const std::string &word : dictionary) {
        FindWordOccurences(text, word, result);
    }
    std::sort(result.begin(), result.end(),
              [](const auto &lhs, const auto &rhs) { return lhs.end < rhs.end; });
    return result;
}

bool IsPossibleToSplit(const std::string &text, const std::vector<Interval> &intervals) {
    std::vector<bool> array(text.size(), false);
    for (int i = 0; i < (int)intervals.size(); ++i) {
        array[intervals[i].end] =
            array[intervals[i].end] || (intervals[i].start == 0 ? true : array[intervals[i].start - 1]);
    }
    return array.back();
}

int main() {
    std::string text;
    std::cin >> text;
    int count = 0;
    std::cin >> count;
    std::vector<std::string> dictionary = GetWords(count);
    std::cout << (IsPossibleToSplit(text, MapWordsToText(text, dictionary)) ? "YES" : "NO");
    return 0;
}

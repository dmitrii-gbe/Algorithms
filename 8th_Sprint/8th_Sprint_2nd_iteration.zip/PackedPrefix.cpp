// https://contest.yandex.ru/contest/26133/run-report/119440270/
/*
-- ПРИНЦИП РАБОТЫ --
Решение принимает массив ЗС, после чего с помошью функций UnPack и MultiplyStringByCount рекурсивно ее
распаковывает. Затем функция GetCommonPrefix ищет общий префикс распакованных строк.

-- ДОКАЗАТЕЛЬСТВО КОРРЕКТНОСТИ --
На вход подается строка, запакованная рекурсивно, то есть при распаковке ЗС может снова получиться
запакованная строка. Поэтому алгоритм рекурсивно доходит до максимальной уровня упаковки, после чего
последательно для каждого уровня распаковывает содержимое, получая, таким образом исходные неупаковованные
строки, для которых затем вычисляется общий префикс максимальной длины.

-- ВРЕМЕННАЯ СЛОЖНОСТЬ --
Распаковка строки имеет сложность O(d*N), где d - число вложенных уровней упаковки, а N - длина распакованной
строки. Поиск общего префикса имеет сложность O(n * M), где n - число строк, а M - длина самой короткой
распакованной строки. В худшем случае сложность этого шага составит O(U), где U - совокупная длина
распакованных строк. Таким образом, общая сложность - не более O(P^2) + O(U), где P и U - совокупная длина
запакованных и распакованных строк, соответственно.

-- ПРОСТРАНСТВЕННАЯ СЛОЖНОСТЬ --

Алгоритм требует не более O(P) памяти, где P - общая длина запакованных строк,
соответственно.
*/

#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

std::vector<std::string> GetStrings(int n) {
    std::vector<std::string> result(n);
    int index = 0;
    while (index != n) {
        std::cin >> result[index++];
    }
    return result;
}

std::string MultiplyStringByCount(int n, const std::string &str) {
    std::string result;
    result.reserve(str.size() * n);
    while (n != 0) {
        result += str;
        --n;
    }
    return result;
}

size_t FindClosingBracket(const std::string &str, size_t start_index) {
    int brackets_count = 1;
    ++start_index;
    while (brackets_count != 0) {
        if (str[start_index] == '[') {
            ++brackets_count;
        } else if (str[start_index] == ']') {
            --brackets_count;
        }
        ++start_index;
    }
    return start_index;
}

std::string UnPack(const std::string &str) {
    std::string result;
    for (size_t i = 0; i < str.size();) {
        if (str[i] >= 'a' && str[i] <= 'z') {
            result += str[i++];
        } else if (str[i] >= '0' && str[i] <= '9') {
            size_t shift = FindClosingBracket(str, i + 1) - i;
            result += MultiplyStringByCount(str[i] - '0', UnPack(str.substr(i + 2, shift - 3)));
            i += shift;
        }
    }
    return result;
}

size_t GetCommonPrefix(const std::string_view s1, const std::string_view s2, size_t max_index) {
    size_t index = 0;
    while (s1[index] == s2[index] && index < std::min(std::min(s1.size(), s2.size()), max_index)) {
        ++index;
    }
    return index;
}

int main() {
    int count = 0;
    std::cin >> count;
    std::vector<std::string> packed_strings = GetStrings(count);
    std::string s = UnPack(packed_strings[0]);
    size_t common_prefix_index = s.size();
    for (size_t i = 1; i < packed_strings.size(); ++i) {
        std::string s1 = UnPack(packed_strings[i]);
        common_prefix_index = std::min(common_prefix_index, GetCommonPrefix(s, s1, common_prefix_index));
        s = std::move(s1);
    }
    std::cout << s.substr(0, common_prefix_index);
    return 0;
}
